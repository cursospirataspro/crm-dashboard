<?php
/**
 * Plugin Name:  CPP CRM Dashboard API for WooCommerce
 * Description:  Endpoint seguro para el dashboard CRM global. Expone pedidos, clientes, país, ciudad, cursos y métricas de WooCommerce.
 * Version:      2.11.0
 * Author:       Cursos Dashboard
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/stripe-fees.php';
require_once __DIR__ . '/includes/email-automations.php';

register_activation_hook( __FILE__, 'cpp_email_automations_activate' );
register_deactivation_hook( __FILE__, 'cpp_email_automations_deactivate' );

// ─────────────────────────────────────────────────────────────
// Compatibilidad con HPOS (High Performance Order Storage)
// ─────────────────────────────────────────────────────────────
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
} );

// ─────────────────────────────────────────────────────────────
// CORS limitado a estas rutas y a los orígenes configurados.
// Se configuran en Ajustes → CPP CRM Dashboard o con la constante
// CPP_CRM_DASHBOARD_ALLOWED_ORIGINS de wp-config.php (tiene prioridad).
// ─────────────────────────────────────────────────────────────
function cpp_crm_dashboard_allowed_origins() {
    $configured = cpp_crm_dashboard_configured_origins();

    $origins = is_array( $configured ) ? $configured : explode( ',', (string) $configured );
    $origins = array_values( array_filter( array_map( function ( $origin ) {
        return rtrim( trim( (string) $origin ), '/' );
    }, $origins ) ) );

    return apply_filters( 'cpp_crm_dashboard_allowed_origins', $origins );
}

function cpp_crm_dashboard_request_origin() {
    return isset( $_SERVER['HTTP_ORIGIN'] )
        ? rtrim( sanitize_text_field( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) ), '/' )
        : '';
}

function cpp_crm_dashboard_origin_is_allowed( $origin ) {
    if ( '' === $origin ) {
        return true;
    }
    $allowed = cpp_crm_dashboard_allowed_origins();
    return in_array( '*', $allowed, true ) || in_array( $origin, $allowed, true );
}

add_filter( 'rest_pre_dispatch', function ( $result, $server, $request ) {
    if ( 0 !== strpos( $request->get_route(), '/cpp-crm-dashboard/v1/' ) ) {
        return $result;
    }

    $origin = cpp_crm_dashboard_request_origin();
    if ( ! cpp_crm_dashboard_origin_is_allowed( $origin ) ) {
        return new WP_Error( 'cors_forbidden', 'Origen no autorizado.', [ 'status' => 403 ] );
    }

    return $result;
}, 10, 3 );

add_filter( 'rest_pre_serve_request', function ( $served, $result, $request, $server ) {
    if ( 0 !== strpos( $request->get_route(), '/cpp-crm-dashboard/v1/' ) ) {
        return $served;
    }

    // Estas respuestas llevan datos de clientes y dependen del token y del origen:
    // ninguna caché (navegador, proxy del hosting, CDN) debe guardarlas. Sin esto,
    // la caché del servidor las entregaba después sin comprobar el token.
    nocache_headers();
    header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private' );
    header( 'X-Accel-Expires: 0' );
    header( 'X-Cache-Enabled: False' );
    header( 'Vary: Origin', false );

    header_remove( 'Access-Control-Allow-Origin' );
    header_remove( 'Access-Control-Allow-Credentials' );

    $origin = cpp_crm_dashboard_request_origin();
    if ( $origin && cpp_crm_dashboard_origin_is_allowed( $origin ) ) {
        $allowed = cpp_crm_dashboard_allowed_origins();
        header( 'Access-Control-Allow-Origin: ' . ( in_array( '*', $allowed, true ) ? '*' : $origin ) );
        header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
        header( 'Access-Control-Allow-Headers: X-CPP-CRM-Dashboard-Token, Content-Type, Authorization' );
        header( 'Access-Control-Max-Age: 600' );
        header( 'Vary: Origin', false );
    }

    return $served;
}, 20, 4 );

// ─────────────────────────────────────────────────────────────
// Registro de la ruta REST
// ─────────────────────────────────────────────────────────────
add_action( 'rest_api_init', function () {
    register_rest_route( 'cpp-crm-dashboard/v1', '/overview', [
        'methods'             => 'GET',
        'callback'            => 'cpp_crm_dashboard_overview',
        'permission_callback' => 'cpp_crm_dashboard_check_token',
        'args' => [
            'from'  => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
            'to'    => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
            'limit' => [ 'required' => false, 'sanitize_callback' => 'absint' ],
            'page'  => [ 'required' => false, 'sanitize_callback' => 'absint' ],
        ],
    ] );
} );

// ─────────────────────────────────────────────────────────────
// Verificación del token de acceso
// ─────────────────────────────────────────────────────────────
function cpp_crm_dashboard_check_token( WP_REST_Request $request ) {
    $expected = cpp_crm_dashboard_token();
    if ( '' === $expected ) {
        return new WP_Error(
            'token_missing',
            'Define el token en Ajustes → CPP CRM Dashboard o CPP_CRM_DASHBOARD_TOKEN en wp-config.php.',
            [ 'status' => 500 ]
        );
    }

    $incoming = $request->get_header( 'x-cpp-crm-dashboard-token' );

    if ( ! $incoming || ! hash_equals( $expected, (string) $incoming ) ) {
        return new WP_Error( 'forbidden', 'Token inválido.', [ 'status' => 403 ] );
    }

    return true;
}

// ─────────────────────────────────────────────────────────────
// Helper: nombre de país desde código ISO
// ─────────────────────────────────────────────────────────────
function cpp_crm_country_name( $code ) {
    if ( ! $code ) return '';
    $countries = WC()->countries ? WC()->countries->get_countries() : [];
    return isset( $countries[ $code ] ) ? html_entity_decode( $countries[ $code ], ENT_QUOTES, 'UTF-8' ) : $code;
}

// ─────────────────────────────────────────────────────────────
// Helper: normalizar estado (quita prefijo wc-)
// ─────────────────────────────────────────────────────────────
function cpp_crm_normalize_status( $status ) {
    return preg_replace( '/^wc-/', '', (string) $status );
}

function cpp_crm_dashboard_cache_version() {
    return (string) get_option( 'cpp_crm_dashboard_cache_version', '1' );
}

function cpp_crm_dashboard_bump_cache_version() {
    update_option( 'cpp_crm_dashboard_cache_version', (string) microtime( true ), false );
}

/**
 * Obtiene los mismos totales que usa WooCommerce Analytics.
 * Los objetos WC_Order no reproducen con exactitud algunos reembolsos y
 * pedidos históricos, por lo que los KPIs deben usar el almacén de reportes.
 */
function cpp_crm_get_analytics_totals( $from, $to ) {
    $query_class = '\\Automattic\\WooCommerce\\Admin\\API\\Reports\\Revenue\\Query';
    if ( ! class_exists( $query_class ) ) return null;

    try {
        $report = new $query_class( [
            'after'    => $from . ' 00:00:00',
            'before'   => $to   . ' 23:59:59',
            'interval' => 'day',
            'page'     => 1,
            'per_page' => 1,
        ] );
        $data = $report->get_data();
        $totals = is_object( $data ) && isset( $data->totals )
            ? $data->totals
            : ( is_array( $data ) && isset( $data['totals'] ) ? $data['totals'] : null );
        if ( ! $totals ) return null;

        $totals = (array) $totals;
        return [
            'orders_count' => (int) ( $totals['orders_count'] ?? 0 ),
            'net_revenue'  => (float) ( $totals['net_revenue'] ?? 0 ),
            'refunds'      => (float) ( $totals['refunds'] ?? 0 ),
            'gross_sales'  => (float) ( $totals['gross_sales'] ?? 0 ),
            'coupons'      => (float) ( $totals['coupons'] ?? 0 ),
        ];
    } catch ( Throwable $error ) {
        return null;
    }
}

add_action( 'woocommerce_new_order', 'cpp_crm_dashboard_bump_cache_version' );
add_action( 'woocommerce_update_order', 'cpp_crm_dashboard_bump_cache_version' );
add_action( 'woocommerce_delete_order', 'cpp_crm_dashboard_bump_cache_version' );
add_action( 'woocommerce_refund_created', 'cpp_crm_dashboard_bump_cache_version' );

// ─────────────────────────────────────────────────────────────
// Endpoint principal
// ─────────────────────────────────────────────────────────────
function cpp_crm_dashboard_overview( WP_REST_Request $request ) {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return new WP_Error( 'woocommerce_missing', 'WooCommerce no está activo.', [ 'status' => 500 ] );
    }

    // Parámetros de fecha y paginación
    $from     = sanitize_text_field( $request->get_param( 'from' ) ?: gmdate( 'Y-m-d', strtotime( '-30 days' ) ) );
    $to       = sanitize_text_field( $request->get_param( 'to' )   ?: gmdate( 'Y-m-d' ) );
    $limit    = $request->get_param( 'limit' ) ? min( absint( $request->get_param( 'limit' ) ), 200 ) : 50;
    $page     = $request->get_param( 'page' )  ? max( 1, absint( $request->get_param( 'page' ) ) ) : 1;

    // Validar formato de fecha
    if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) $from = gmdate( 'Y-m-d', strtotime( '-30 days' ) );
    if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) )   $to   = gmdate( 'Y-m-d' );

    if ( $from > $to ) {
        return new WP_Error( 'invalid_date_range', 'La fecha inicial no puede ser posterior a la fecha final.', [ 'status' => 400 ] );
    }

    // Rango de fechas inclusivo (inicio del día "from" → final del día "to")
    $date_range = $from . 'T00:00:00' . '...' . $to . 'T23:59:59';

    $date_type = cpp_crm_analytics_date_type();

    $cache_key = 'cpp_crm_overview_' . md5( implode( '|', [
        '2.11.0',
        $date_type,
        $from,
        $to,
        (string) $limit,
        (string) $page,
        cpp_crm_dashboard_cache_version(),
    ] ) );
    $cached = get_transient( $cache_key );
    if ( false !== $cached && is_array( $cached ) ) {
        return rest_ensure_response( $cached );
    }

    // Índice de pedidos del periodo, con el mismo criterio que WooCommerce Analytics:
    // los pedidos que generan ingresos se asignan al periodo por la fecha que usa
    // Analytics (por defecto la de pago), no por la de creación.
    $index = cpp_crm_dashboard_order_index( $date_range, $date_type );
    if ( is_wp_error( $index ) ) {
        return $index;
    }

    $total_orders = count( $index['ids'] );
    $total_pages  = max( 1, (int) ceil( $total_orders / $limit ) );
    $page_ids     = array_slice( $index['ids'], ( $page - 1 ) * $limit, $limit );
    $counted      = $index['counted'];

    $orders = [];
    foreach ( $page_ids as $order_id ) {
        $order = wc_get_order( $order_id );
        if ( $order ) {
            $orders[] = $order;
        }
    }

    $normalized = [];

    foreach ( $orders as $order ) {
        if ( ! $order instanceof WC_Order ) continue; // skip WC_Order_Refund y otros

        $products      = [];
        foreach ( $order->get_items() as $item ) {
            $products[] = [
                'name'       => $item->get_name(),
                'quantity'   => (int) $item->get_quantity(),
                'total'      => (float) $item->get_total(),
                'product_id' => (int) $item->get_product_id(),
            ];
        }

        $country_code = (string) $order->get_billing_country();
        $city         = (string) $order->get_billing_city();
        $first        = (string) $order->get_billing_first_name();
        $last         = (string) $order->get_billing_last_name();
        $name         = trim( $first . ' ' . $last );
        if ( ! $name ) $name = 'Cliente #' . $order->get_customer_id();

        $created        = $order->get_date_created();
        $in_analytics   = isset( $counted[ $order->get_id() ] );
        $analytics_date = $in_analytics ? cpp_crm_order_analytics_date( $order, $date_type ) : null;
        $shown_date     = $analytics_date ?: $created;
        $gateway_fee    = cpp_crm_order_gateway_fee( $order );

        $normalized[] = [
            'id'             => $order->get_id(),
            'number'         => '#' . $order->get_order_number(),
            // Fecha con la que WooCommerce Analytics asigna el pedido al periodo.
            'date'           => $shown_date ? $shown_date->date( 'c' ) : '',
            'date_created'   => $created ? $created->date( 'c' ) : '',
            // false = Analytics no lo cuenta (p. ej. en espera o reembolsado sin fecha de pago).
            'counts_in_analytics' => $in_analytics,
            'customer'       => $name,
            'customer_email' => (string) $order->get_billing_email(),
            'status'         => cpp_crm_normalize_status( $order->get_status() ),
            'total'          => (float) $order->get_total(),
            'net_total'      => (float) ( $order->get_subtotal() - $order->get_discount_total() ),
            'total_refunded' => (float) $order->get_total_refunded(),
            'payment_method' => $order->get_payment_method_title() ?: (string) $order->get_payment_method(),
            // Comisión real de la pasarela guardada en el pedido (null si la pasarela no la registró).
            'gateway'              => $gateway_fee['gateway'],
            'gateway_fee'          => $gateway_fee['fee'],
            'gateway_net'          => $gateway_fee['net'],
            'gateway_fee_currency' => $gateway_fee['currency'],
            'country_code'   => $country_code,
            'country'        => cpp_crm_country_name( $country_code ),
            'city'           => $city,
            'products'       => $products,
        ];
    }

    $response_data = [
        'site'         => get_bloginfo( 'name' ),
        'from'         => $from,
        'to'           => $to,
        'total'        => count( $normalized ),
        'total_orders' => $total_orders,
        'total_pages'  => $total_pages,
        'current_page' => $page,
        'per_page'     => $limit,
        'date_type'    => $date_type,
        'orders'       => $normalized,
        'analytics'    => 1 === $page ? cpp_crm_get_analytics_totals( $from, $to ) : null,
        'generated_at' => gmdate( 'c' ),
    ];

    set_transient( $cache_key, $response_data, MINUTE_IN_SECONDS );
    return rest_ensure_response( $response_data );
}

// ─────────────────────────────────────────────────────────────
// Comisión real de la pasarela de pago, guardada en cada pedido
// ─────────────────────────────────────────────────────────────

/** Primer metadato numérico entre las claves dadas, o null. */
function cpp_crm_order_meta_number( $order, array $keys ) {
    foreach ( $keys as $key ) {
        $value = $order->get_meta( $key, true );
        if ( is_numeric( $value ) ) {
            return (float) $value;
        }
    }
    return null;
}

/** Primer metadato de texto no vacío entre las claves dadas, o ''. */
function cpp_crm_order_meta_text( $order, array $keys ) {
    foreach ( $keys as $key ) {
        $value = $order->get_meta( $key, true );
        if ( is_string( $value ) && '' !== $value ) {
            return $value;
        }
    }
    return '';
}

/**
 * Comisión que cobró la pasarela, tal como la guardó su plugin en el pedido.
 *
 * - Stripe: `_stripe_fee`, `_stripe_net`, `_stripe_currency`.
 * - PayPal Payments: `_ppcp_paypal_fees` (paypal_fee / net_amount) o `PayPal Transaction Fee`.
 * - Pedidos migrados de la tienda anterior: las mismas claves con prefijo `_cpp_hist_`.
 *
 * Nunca se estima: si la pasarela no registró la comisión, `fee` es null.
 */
function cpp_crm_order_gateway_fee( $order ) {
    $method  = strtolower( (string) $order->get_payment_method() );
    $gateway = '';
    if ( 0 === strpos( $method, 'stripe' ) ) {
        $gateway = 'stripe';
    } elseif ( 0 === strpos( $method, 'ppcp' ) || false !== strpos( $method, 'paypal' ) ) {
        $gateway = 'paypal';
    }

    $stripe = null;
    // '_cpp_crm_stripe_*' es la comisión real que este plugin consultó a Stripe.
    $fee    = cpp_crm_order_meta_number( $order, [ '_stripe_fee', '_cpp_hist_stripe_fee', '_cpp_crm_stripe_fee' ] );
    if ( null !== $fee ) {
        $stripe = [
            'gateway'  => 'stripe',
            'fee'      => round( abs( $fee ), 2 ),
            'net'      => cpp_crm_order_meta_number( $order, [ '_stripe_net', '_cpp_hist_stripe_net', '_cpp_crm_stripe_net' ] ),
            'currency' => strtoupper( cpp_crm_order_meta_text( $order, [ '_stripe_currency', '_cpp_hist_stripe_currency', '_cpp_crm_stripe_currency' ] ) ),
        ];
    } elseif ( 'stripe' === $gateway ) {
        // Sin comisión guardada: se consulta a Stripe (si hay clave) y queda guardada en el pedido.
        $resolved = cpp_crm_stripe_resolve_missing_fee( $order );
        if ( $resolved ) {
            $stripe = [ 'gateway' => 'stripe', 'fee' => $resolved['fee'], 'net' => $resolved['net'], 'currency' => $resolved['currency'] ];
        }
    }

    $paypal = null;
    foreach ( [ '_ppcp_paypal_fees', '_cpp_hist_ppcp_paypal_fees' ] as $key ) {
        $raw = $order->get_meta( $key, true );
        if ( is_string( $raw ) && '' !== $raw ) {
            $decoded = json_decode( $raw, true );
            $raw     = is_array( $decoded ) ? $decoded : maybe_unserialize( $raw );
        }
        if ( is_array( $raw ) && isset( $raw['paypal_fee']['value'] ) && is_numeric( $raw['paypal_fee']['value'] ) ) {
            $paypal = [
                'gateway'  => 'paypal',
                'fee'      => round( abs( (float) $raw['paypal_fee']['value'] ), 2 ),
                'net'      => isset( $raw['net_amount']['value'] ) && is_numeric( $raw['net_amount']['value'] )
                    ? (float) $raw['net_amount']['value'] : null,
                'currency' => strtoupper( (string) ( $raw['paypal_fee']['currency_code'] ?? '' ) ),
            ];
            break;
        }
    }
    if ( null === $paypal ) {
        $fee = cpp_crm_order_meta_number( $order, [ 'PayPal Transaction Fee', '_cpp_hist_paypaltransactionfee' ] );
        if ( null !== $fee ) {
            $paypal = [ 'gateway' => 'paypal', 'fee' => round( abs( $fee ), 2 ), 'net' => null, 'currency' => '' ];
        }
    }

    // Se prefiere la comisión de la pasarela con la que se pagó el pedido.
    $found = 'paypal' === $gateway ? ( $paypal ?: $stripe ) : ( $stripe ?: $paypal );
    if ( ! $found ) {
        return [ 'gateway' => $gateway, 'fee' => null, 'net' => null, 'currency' => '' ];
    }
    if ( '' !== $gateway ) {
        $found['gateway'] = $gateway;
    }
    if ( null === $found['net'] ) {
        $found['net'] = round( (float) $order->get_total() - $found['fee'], 2 );
    }
    if ( '' === $found['currency'] ) {
        $found['currency'] = (string) $order->get_currency();
    }
    return $found;
}

// ─────────────────────────────────────────────────────────────
// Mismo criterio de fechas que WooCommerce Analytics
// ─────────────────────────────────────────────────────────────

/** Estados que Analytics suma como ingresos (excluye pendiente, cancelado y fallido). */
function cpp_crm_revenue_statuses() {
    return [ 'completed', 'processing', 'on-hold', 'refunded' ];
}

/** Tipo de fecha de Analytics (Analítica → Ajustes → «Tipo de fecha»). Por defecto, la de pago. */
function cpp_crm_analytics_date_type() {
    $type = (string) get_option( 'woocommerce_date_type', 'date_paid' );
    return in_array( $type, [ 'date_created', 'date_paid', 'date_completed' ], true ) ? $type : 'date_paid';
}

/** Fecha con la que Analytics asigna un pedido al periodo, o null si no tiene. */
function cpp_crm_order_analytics_date( $order, $date_type ) {
    if ( 'date_paid' === $date_type ) {
        return $order->get_date_paid();
    }
    if ( 'date_completed' === $date_type ) {
        return $order->get_date_completed();
    }
    return $order->get_date_created();
}

/**
 * IDs de los pedidos del periodo, en el orden en que se paginan.
 *
 * - `counted`: pedidos con ingresos cuya fecha de Analytics cae en el periodo.
 *   Son exactamente los que suma WooCommerce Analytics.
 * - Después van los que Analytics no cuenta pero el CRM sigue mostrando:
 *   pedidos con estado de ingresos sin esa fecha (p. ej. en espera sin pagar),
 *   y los pendientes y cancelados, ambos por fecha de creación.
 *
 * Un pedido creado en el periodo pero pagado fuera de él no aparece: pertenece
 * al periodo de su fecha de pago, igual que en Analytics.
 */
function cpp_crm_dashboard_order_index( $date_range, $date_type ) {
    $cache_key = 'cpp_crm_index_' . md5( implode( '|', [ '2.8.0', $date_type, $date_range, cpp_crm_dashboard_cache_version() ] ) );
    $cached    = get_transient( $cache_key );
    if ( is_array( $cached ) && isset( $cached['ids'], $cached['counted'] ) ) {
        return $cached;
    }

    $base = [ 'limit' => -1, 'return' => 'ids', 'orderby' => 'date', 'order' => 'DESC', 'type' => 'shop_order' ];

    $counted_ids = wc_get_orders( $base + [
        'status'   => cpp_crm_revenue_statuses(),
        $date_type => $date_range,
    ] );
    $other_ids = wc_get_orders( $base + [
        'status'       => [ 'pending', 'cancelled' ],
        'date_created' => $date_range,
    ] );
    if ( ! is_array( $counted_ids ) || ! is_array( $other_ids ) ) {
        return new WP_Error( 'orders_query_failed', 'No se pudieron consultar los pedidos.', [ 'status' => 500 ] );
    }

    $counted_ids = array_map( 'intval', $counted_ids );
    $counted     = array_fill_keys( $counted_ids, true );
    $undated     = [];

    if ( 'date_created' !== $date_type ) {
        $created_ids = wc_get_orders( $base + [
            'status'       => cpp_crm_revenue_statuses(),
            'date_created' => $date_range,
        ] );
        if ( ! is_array( $created_ids ) ) {
            return new WP_Error( 'orders_query_failed', 'No se pudieron consultar los pedidos.', [ 'status' => 500 ] );
        }
        foreach ( array_map( 'intval', $created_ids ) as $order_id ) {
            if ( isset( $counted[ $order_id ] ) ) {
                continue;
            }
            $order = wc_get_order( $order_id );
            // Con fecha de Analytics fuera del periodo: se cuenta en ese otro periodo.
            if ( $order && ! cpp_crm_order_analytics_date( $order, $date_type ) ) {
                $undated[] = $order_id;
            }
        }
    }

    $index = [
        'ids'     => array_values( array_unique( array_merge( $counted_ids, $undated, array_map( 'intval', $other_ids ) ) ) ),
        'counted' => $counted,
    ];
    set_transient( $cache_key, $index, MINUTE_IN_SECONDS );
    return $index;
}

// =============================================================
// PAYPAL API PROXY
// Endpoints: /paypal/summary  /paypal/transactions
// Define en wp-config.php:
//   define('CPP_PAYPAL_CLIENT_ID',     'TU_CLIENT_ID_LIVE');
//   define('CPP_PAYPAL_CLIENT_SECRET', 'TU_SECRET_LIVE');
//   define('CPP_PAYPAL_SANDBOX_CLIENT_ID',     'TU_CLIENT_ID_SANDBOX');
//   define('CPP_PAYPAL_SANDBOX_CLIENT_SECRET', 'TU_SECRET_SANDBOX');
// Nunca guardes estas credenciales en el JavaScript público del dashboard.
// =============================================================

add_action( 'rest_api_init', function () {
    $base_args = [
        'methods'             => 'GET',
        'permission_callback' => 'cpp_crm_dashboard_check_token',
    ];

    register_rest_route( 'cpp-crm-dashboard/v1', '/paypal/summary', array_merge( $base_args, [
        'callback' => 'cpp_paypal_summary',
        'args'     => [
            'from' => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
            'to'   => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
            'mode' => [ 'required' => false, 'sanitize_callback' => 'sanitize_key' ],
        ],
    ] ) );

    register_rest_route( 'cpp-crm-dashboard/v1', '/paypal/transactions', array_merge( $base_args, [
        'callback' => 'cpp_paypal_transactions',
        'args'     => [
            'from' => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
            'to'   => [ 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ],
            'page' => [ 'required' => false, 'sanitize_callback' => 'absint' ],
            'mode' => [ 'required' => false, 'sanitize_callback' => 'sanitize_key' ],
        ],
    ] ) );
} );

function cpp_paypal_get_token( $mode = 'live' ) {
    $sandbox = $mode === 'sandbox';
    // Constantes de wp-config.php o, en modo real, los ajustes guardados en WordPress.
    list( $pp_client_id, $pp_client_secret ) = cpp_crm_paypal_credentials( $sandbox ? 'sandbox' : 'live' );
    if ( '' === $pp_client_id || '' === $pp_client_secret ) {
        return new WP_Error('paypal_no_config', 'Configura las credenciales PayPal en Ajustes → CPP CRM Dashboard (o en wp-config.php).', [ 'status' => 409 ]);
    }

    $cached = get_transient('cpp_paypal_access_token_' . $mode);
    if ( $cached ) return $cached;

    $base = $sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';
    $response = wp_remote_post( $base . '/v1/oauth2/token', [
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode( $pp_client_id . ":" . $pp_client_secret ),
            'Content-Type'  => 'application/x-www-form-urlencoded',
        ],
        'body'    => 'grant_type=client_credentials',
        'timeout' => 10,
        'sslverify' => true,
    ] );

    if ( is_wp_error($response) ) return $response;

    $body = json_decode( wp_remote_retrieve_body($response), true );
    if ( empty($body['access_token']) ) {
        return new WP_Error('paypal_token_error', 'Error obteniendo token PayPal: ' . wp_remote_retrieve_body($response));
    }

    $expires = max(60, intval($body['expires_in'] ?? 3600) - 60);
    set_transient('cpp_paypal_access_token_' . $mode, $body['access_token'], $expires);
    return $body['access_token'];
}

function cpp_paypal_fetch_transactions( $from, $to, $page = 1, $mode = 'live' ) {
    $cache_key = 'cpp_crm_paypal_' . md5( implode( '|', [ $mode, $from, $to, (string) $page ] ) );
    $cached = get_transient( $cache_key );
    if ( false !== $cached && is_array( $cached ) ) {
        return $cached;
    }

    $token = cpp_paypal_get_token($mode);
    if ( is_wp_error($token) ) return $token;

    $url = add_query_arg( [
        'start_date'         => $from . 'T00:00:00-0000',
        'end_date'           => $to   . 'T23:59:59-0000',
        'transaction_status' => 'S',
        'page_size'          => 100,
        'page'               => $page,
        'fields'             => 'all',
    ], ($mode === 'sandbox' ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com') . '/v1/reporting/transactions' );

    $response = wp_remote_get( $url, [
        'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        ],
        'timeout'   => 10,
        'sslverify' => true,
    ] );

    if ( is_wp_error($response) ) return $response;
    $body = json_decode( wp_remote_retrieve_body($response), true );
    $code = wp_remote_retrieve_response_code($response);
    if ( $code >= 400 || ! is_array( $body ) ) {
        return new WP_Error(
            'paypal_api_error',
            is_array( $body ) && ! empty( $body['message'] ) ? $body['message'] : 'PayPal devolvió una respuesta no válida.',
            [ 'status' => 502 ]
        );
    }

    set_transient( $cache_key, $body, 5 * MINUTE_IN_SECONDS );
    return $body;
}

function cpp_paypal_transactions( WP_REST_Request $request ) {
    $from = $request->get_param('from') ?: date('Y-m-d', strtotime('-30 days'));
    $to   = $request->get_param('to')   ?: date('Y-m-d');
    $page = max(1, intval($request->get_param('page') ?: 1));
    $mode = $request->get_param('mode') === 'sandbox' ? 'sandbox' : 'live';

    $data = cpp_paypal_fetch_transactions( $from, $to, $page, $mode );
    if ( is_wp_error($data) ) return $data;

    $txns = $data['transaction_details'] ?? [];

    $result = array_map( function($t) {
        $info  = $t['transaction_info'] ?? [];
        $payer = $t['payer_info']       ?? [];
        $name  = $payer['payer_name']['alternate_full_name'] ?? ($payer['email_address'] ?? 'Desconocido');
        $amt   = floatval($info['transaction_amount']['value'] ?? 0);
        $fee   = floatval($info['fee_amount']['value']         ?? 0);
        return [
            'id'          => $info['transaction_id']                          ?? '',
            'date'        => $info['transaction_initiation_date']             ?? '',
            'amount'      => $amt,
            'fee'         => abs($fee),
            'net'         => $amt - abs($fee),
            'currency'    => $info['transaction_amount']['currency_code']     ?? 'USD',
            'status'      => $info['transaction_status']                      ?? '',
            'event_code'  => $info['transaction_event_code']                  ?? '',
            'subject'     => $info['transaction_subject']                     ?? '',
            'payer_name'  => $name,
            'payer_email' => $payer['email_address']                          ?? '',
            'country'     => $payer['address']['country_code']                ?? '',
        ];
    }, $txns );

    return rest_ensure_response( [
        'transactions' => $result,
        'total_items'  => intval($data['total_items']  ?? count($result)),
        'total_pages'  => intval($data['total_pages']  ?? 1),
        'page'         => $page,
    ] );
}

function cpp_paypal_summary( WP_REST_Request $request ) {
    $from = $request->get_param('from') ?: date('Y-m-d', strtotime('-30 days'));
    $to   = $request->get_param('to')   ?: date('Y-m-d');
    $mode = $request->get_param('mode') === 'sandbox' ? 'sandbox' : 'live';

    $data = cpp_paypal_fetch_transactions( $from, $to, 1, $mode );
    if ( is_wp_error($data) ) return $data;

    $txns = $data['transaction_details'] ?? [];

    $total_gross = 0;
    $total_fees  = 0;
    $count       = 0;
    $by_country  = [];
    $by_customer = [];
    $by_day      = [];

    foreach ($txns as $t) {
        $info    = $t['transaction_info'] ?? [];
        $payer   = $t['payer_info']       ?? [];
        $amt     = floatval($info['transaction_amount']['value'] ?? 0);
        $fee     = floatval($info['fee_amount']['value']         ?? 0);
        $date    = substr($info['transaction_initiation_date'] ?? '', 0, 10);
        $country = $payer['address']['country_code']  ?? 'XX';
        $email   = $payer['email_address']            ?? 'desconocido';
        $name    = $payer['payer_name']['alternate_full_name'] ?? $email;

        $total_gross += $amt;
        $total_fees  += abs($fee);
        $count++;

        $by_country[$country] = round(($by_country[$country] ?? 0) + $amt, 2);

        if ( ! isset($by_customer[$email]) ) {
            $by_customer[$email] = [ 'name' => $name, 'email' => $email, 'total' => 0, 'orders' => 0 ];
        }
        $by_customer[$email]['total']  = round($by_customer[$email]['total'] + $amt, 2);
        $by_customer[$email]['orders'] += 1;

        $by_day[$date] = round(($by_day[$date] ?? 0) + $amt, 2);
    }

    arsort($by_country);
    uasort($by_customer, function($a, $b) { return $b['total'] <=> $a['total']; });
    ksort($by_day);

    return rest_ensure_response( [
        'total_gross'   => round($total_gross, 2),
        'total_fees'    => round($total_fees,  2),
        'total_net'     => round($total_gross - $total_fees, 2),
        'count'         => $count,
        'avg_order'     => $count ? round($total_gross / $count, 2) : 0,
        'by_country'    => $by_country,
        'top_customers' => array_values(array_slice($by_customer, 0, 20)),
        'by_day'        => $by_day,
        'period'        => [ 'from' => $from, 'to' => $to ],
    ] );
}

// =============================================================
// BREVO EMAIL PROXY
// =============================================================
add_action( 'rest_api_init', function () {
    register_rest_route( 'cpp-crm-dashboard/v1', '/brevo/test', [
        'methods'             => 'GET',
        'callback'            => 'cpp_brevo_test',
        'permission_callback' => 'cpp_crm_dashboard_check_token',
    ] );
    register_rest_route( 'cpp-crm-dashboard/v1', '/brevo/send', [
        'methods'             => 'POST',
        'callback'            => 'cpp_brevo_send',
        'permission_callback' => 'cpp_crm_dashboard_check_token',
    ] );
    register_rest_route( 'cpp-crm-dashboard/v1', '/brevo/events', [
        'methods'             => 'GET',
        'callback'            => 'cpp_brevo_events',
        'permission_callback' => 'cpp_crm_dashboard_check_token',
    ] );
    register_rest_route( 'cpp-crm-dashboard/v1', '/brevo/senders', [
        'methods'             => 'GET',
        'callback'            => 'cpp_brevo_senders',
        'permission_callback' => 'cpp_crm_dashboard_check_token',
    ] );
} );

function cpp_brevo_get_config() {
    return [
        'api_key'      => defined('CPP_BREVO_API_KEY')      ? CPP_BREVO_API_KEY      : '',
        'sender_name'  => defined('CPP_BREVO_SENDER_NAME')  ? CPP_BREVO_SENDER_NAME  : 'CRM Dashboard',
        'sender_email' => defined('CPP_BREVO_SENDER_EMAIL') ? CPP_BREVO_SENDER_EMAIL : '',
    ];
}

function cpp_brevo_test( WP_REST_Request $request ) {
    $cfg = cpp_brevo_get_config();
    if ( empty($cfg['api_key']) ) {
        return new WP_Error( 'brevo_no_key', 'CPP_BREVO_API_KEY no definida en wp-config.php', [ 'status' => 500 ] );
    }
    $cached = get_transient( 'cpp_crm_brevo_account' );
    if ( false !== $cached && is_array( $cached ) ) {
        return rest_ensure_response( $cached );
    }
    $response = wp_remote_get( 'https://api.brevo.com/v3/account', [
        'headers' => [
            'api-key' => $cfg['api_key'],
            'Accept'  => 'application/json',
        ],
        'timeout' => 10,
    ] );
    if ( is_wp_error($response) ) {
        return new WP_Error( 'brevo_error', $response->get_error_message(), [ 'status' => 502 ] );
    }
    $body = json_decode( wp_remote_retrieve_body($response), true );
    $code = wp_remote_retrieve_response_code($response);
    if ( $code !== 200 ) {
        return new WP_Error( 'brevo_error', $body['message'] ?? 'Error desconocido', [ 'status' => $code ] );
    }
    $data = [
        'success'      => true,
        'account'      => $body['email'] ?? '',
        'plan'         => $body['plan'][0]['type'] ?? '',
        'credits'      => $body['plan'][0]['credits'] ?? 0,
        'creditsUsed'  => $body['plan'][0]['creditsUsed'] ?? 0,
        'creditsLeft'  => max(0, ($body['plan'][0]['credits'] ?? 0) - ($body['plan'][0]['creditsUsed'] ?? 0)),
    ];
    set_transient( 'cpp_crm_brevo_account', $data, MINUTE_IN_SECONDS );
    return rest_ensure_response( $data );
}

function cpp_brevo_send( WP_REST_Request $request ) {
    $cfg = cpp_brevo_get_config();
    if ( empty($cfg['api_key']) ) {
        return new WP_Error( 'brevo_no_key', 'CPP_BREVO_API_KEY no definida en wp-config.php', [ 'status' => 500 ] );
    }
    $to_email    = sanitize_email( $request->get_param('to_email') );
    $to_name     = sanitize_text_field( $request->get_param('to_name') );
    $subject     = sanitize_text_field( $request->get_param('subject') );
    $html        = cpp_brevo_sanitize_email_html( $request->get_param('html_content') );
    $text        = sanitize_textarea_field( $request->get_param('text_content') );
    $reply_to    = sanitize_email( $request->get_param('reply_to') );
    $scheduled   = sanitize_text_field( $request->get_param('scheduled_at') );
    $raw_tags    = $request->get_param('tags');
    $tags        = is_array($raw_tags)
        ? array_values(array_filter(array_map('sanitize_key', $raw_tags)))
        : [];

    if ( ! $to_email || ! $subject || ! $html ) {
        return new WP_Error( 'brevo_missing', 'Faltan campos: to_email, subject, html_content', [ 'status' => 400 ] );
    }

    $payload = [
        'sender'      => [ 'name' => $cfg['sender_name'], 'email' => $cfg['sender_email'] ],
        'to'          => [ [ 'email' => $to_email, 'name' => $to_name ?: $to_email ] ],
        'subject'     => $subject,
        'htmlContent' => $html,
    ];
    if ( $text ) {
        $payload['textContent'] = $text;
    }
    if ( $reply_to ) {
        $payload['replyTo'] = [ 'email' => $reply_to, 'name' => $cfg['sender_name'] ];
    }
    if ( $tags ) {
        $payload['tags'] = array_slice($tags, 0, 10);
    }
    if ( $scheduled ) {
        $scheduled_ts = strtotime($scheduled);
        if ( ! $scheduled_ts || $scheduled_ts <= time() || $scheduled_ts > time() + (72 * HOUR_IN_SECONDS) ) {
            return new WP_Error( 'brevo_schedule_invalid', 'La fecha programada debe estar entre ahora y las próximas 72 horas', [ 'status' => 400 ] );
        }
        $payload['scheduledAt'] = gmdate('Y-m-d\TH:i:s.000\Z', $scheduled_ts);
    }

    $response = wp_remote_post( 'https://api.brevo.com/v3/smtp/email', [
        'headers' => [
            'api-key'      => $cfg['api_key'],
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ],
        'body'    => wp_json_encode($payload),
        'timeout' => 10,
    ] );

    if ( is_wp_error($response) ) {
        return new WP_Error( 'brevo_error', $response->get_error_message(), [ 'status' => 502 ] );
    }
    $body = json_decode( wp_remote_retrieve_body($response), true );
    $code = wp_remote_retrieve_response_code($response);
    if ( $code >= 400 ) {
        return new WP_Error( 'brevo_send_error', $body['message'] ?? 'Error al enviar', [ 'status' => $code ] );
    }
    return rest_ensure_response( [ 'success' => true, 'messageId' => $body['messageId'] ?? '' ] );
}

/**
 * Conserva la estructura de un email HTML (tablas, estilos inline y metadatos)
 * sin permitir scripts, iframes ni manejadores de eventos.
 */
function cpp_brevo_sanitize_email_html( $html ) {
    $allowed = wp_kses_allowed_html('post');
    $global_attrs = [
        'style' => true, 'class' => true, 'id' => true, 'title' => true,
        'role' => true, 'aria-hidden' => true, 'lang' => true,
    ];
    $allowed['html'] = [ 'lang' => true ];
    $allowed['head'] = [];
    $allowed['meta'] = [ 'charset' => true, 'name' => true, 'content' => true ];
    $allowed['body'] = array_merge($global_attrs, [ 'bgcolor' => true ]);
    $allowed['table'] = array_merge($global_attrs, [
        'width' => true, 'height' => true, 'align' => true, 'bgcolor' => true,
        'border' => true, 'cellpadding' => true, 'cellspacing' => true,
    ]);
    foreach (['thead','tbody','tfoot','tr','td','th'] as $tag) {
        $allowed[$tag] = array_merge($global_attrs, [
            'width' => true, 'height' => true, 'align' => true,
            'valign' => true, 'bgcolor' => true, 'colspan' => true, 'rowspan' => true,
        ]);
    }
    $allowed['img'] = array_merge($allowed['img'] ?? [], [
        'src' => true, 'alt' => true, 'width' => true, 'height' => true,
        'style' => true, 'border' => true, 'title' => true,
    ]);
    $allowed['a'] = array_merge($allowed['a'] ?? [], [
        'href' => true, 'target' => true, 'rel' => true, 'style' => true, 'title' => true,
    ]);
    foreach (['div','span','p','h1','h2','h3','h4','h5','h6','ul','ol','li','blockquote','strong','em','u','br','hr'] as $tag) {
        $allowed[$tag] = array_merge($allowed[$tag] ?? [], $global_attrs);
    }
    return wp_kses( wp_unslash((string) $html), $allowed );
}

function cpp_brevo_events( WP_REST_Request $request ) {
    $cfg = cpp_brevo_get_config();
    if ( empty($cfg['api_key']) ) {
        return new WP_Error( 'brevo_no_key', 'CPP_BREVO_API_KEY no definida', [ 'status' => 500 ] );
    }
    $cached = get_transient( 'cpp_crm_brevo_events' );
    if ( false !== $cached && is_array( $cached ) ) {
        return rest_ensure_response( $cached );
    }
    $response = wp_remote_get( 'https://api.brevo.com/v3/smtp/statistics/events?limit=20&sort=desc', [
        'headers' => [ 'api-key' => $cfg['api_key'], 'Accept' => 'application/json' ],
        'timeout' => 10,
    ] );
    if ( is_wp_error($response) ) {
        return new WP_Error( 'brevo_error', $response->get_error_message(), [ 'status' => 502 ] );
    }
    $body = json_decode( wp_remote_retrieve_body($response), true );
    $code = wp_remote_retrieve_response_code($response);
    if ( $code >= 400 ) {
        return new WP_Error( 'brevo_error', $body['message'] ?? 'Error', [ 'status' => $code ] );
    }
    set_transient( 'cpp_crm_brevo_events', $body, MINUTE_IN_SECONDS );
    return rest_ensure_response( $body );
}

function cpp_brevo_senders( WP_REST_Request $request ) {
    $cfg = cpp_brevo_get_config();
    if ( empty($cfg['api_key']) ) {
        return new WP_Error( 'brevo_no_key', 'CPP_BREVO_API_KEY no definida', [ 'status' => 500 ] );
    }
    $cached = get_transient( 'cpp_crm_brevo_senders' );
    if ( false !== $cached && is_array( $cached ) ) {
        return rest_ensure_response( $cached );
    }
    $response = wp_remote_get( 'https://api.brevo.com/v3/senders', [
        'headers' => [ 'api-key' => $cfg['api_key'], 'Accept' => 'application/json' ],
        'timeout' => 10,
    ] );
    if ( is_wp_error($response) ) {
        return new WP_Error( 'brevo_error', $response->get_error_message(), [ 'status' => 502 ] );
    }
    $body = json_decode( wp_remote_retrieve_body($response), true );
    $code = wp_remote_retrieve_response_code($response);
    if ( $code >= 400 ) {
        return new WP_Error( 'brevo_error', $body['message'] ?? 'Error', [ 'status' => $code ] );
    }
    set_transient( 'cpp_crm_brevo_senders', $body, 5 * MINUTE_IN_SECONDS );
    return rest_ensure_response( $body );
}
